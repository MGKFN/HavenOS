#!/bin/bash
exec python3 /usr/lib/morrowstore/main.py "$@"
