#!/bin/bash
# MorrowStore launcher
export GTK_A11Y=none
LOG="${XDG_CACHE_HOME:-$HOME/.cache}/morrowstore.log"
mkdir -p "$(dirname "$LOG")" 2>/dev/null
exec python3 /usr/lib/morrowstore/main.py "$@" 2>&1 | tee -a "$LOG"
