"""
MorrowStore — Main Window
"""
import gi
gi.require_version("Gtk", "4.0")
gi.require_version("Adw", "1")
from gi.repository import Gtk, Adw, GLib, Gio
from catalog import load_catalog
from installer import Installer
from app_card import AppCard

class MorrowStoreWindow(Adw.ApplicationWindow):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.set_title("MorrowStore")
        self.set_default_size(1000, 680)

        self.installer = Installer()
        self.catalog = load_catalog()

        # Root layout
        self.toast_overlay = Adw.ToastOverlay()
        self.set_content(self.toast_overlay)

        box = Gtk.Box(orientation=Gtk.Orientation.VERTICAL)
        self.toast_overlay.set_child(box)

        # Header bar
        header = Adw.HeaderBar()
        header.add_css_class("flat")

        self.search_entry = Gtk.SearchEntry()
        self.search_entry.set_placeholder_text("Search apps...")
        self.search_entry.set_hexpand(True)
        self.search_entry.connect("search-changed", self.on_search)
        header.set_title_widget(self.search_entry)

        box.append(header)

        # Category sidebar + app grid
        content = Gtk.Box(orientation=Gtk.Orientation.HORIZONTAL)
        content.set_vexpand(True)
        box.append(content)

        # Sidebar
        sidebar = self._build_sidebar()
        content.append(sidebar)

        # Separator
        sep = Gtk.Separator(orientation=Gtk.Orientation.VERTICAL)
        content.append(sep)

        # Scrollable app grid
        scroll = Gtk.ScrolledWindow()
        scroll.set_hexpand(True)
        scroll.set_vexpand(True)
        content.append(scroll)

        self.flow = Gtk.FlowBox()
        self.flow.set_valign(Gtk.Align.START)
        self.flow.set_max_children_per_line(4)
        self.flow.set_min_children_per_line(2)
        self.flow.set_row_spacing(12)
        self.flow.set_column_spacing(12)
        self.flow.set_margin_top(16)
        self.flow.set_margin_bottom(16)
        self.flow.set_margin_start(16)
        self.flow.set_margin_end(16)
        self.flow.set_homogeneous(True)
        scroll.set_child(self.flow)

        self.current_category = "All"
        self._populate_apps()

    def _build_sidebar(self):
        sidebar_scroll = Gtk.ScrolledWindow()
        sidebar_scroll.set_policy(Gtk.PolicyType.NEVER, Gtk.PolicyType.AUTOMATIC)
        sidebar_scroll.set_size_request(180, -1)

        list_box = Gtk.ListBox()
        list_box.set_selection_mode(Gtk.SelectionMode.SINGLE)
        list_box.add_css_class("navigation-sidebar")
        list_box.connect("row-selected", self.on_category_selected)
        sidebar_scroll.set_child(list_box)

        categories = ["All"] + sorted({app["category"] for app in self.catalog})
        for cat in categories:
            row = Gtk.ListBoxRow()
            label = Gtk.Label(label=cat)
            label.set_halign(Gtk.Align.START)
            label.set_margin_start(12)
            label.set_margin_top(8)
            label.set_margin_bottom(8)
            row.set_child(label)
            row.category = cat
            list_box.append(row)

        # Select "All" by default
        list_box.select_row(list_box.get_row_at_index(0))
        return sidebar_scroll

    def _populate_apps(self, search=""):
        # Clear existing
        while (child := self.flow.get_first_child()):
            self.flow.remove(child)

        for app in self.catalog:
            if self.current_category != "All" and app["category"] != self.current_category:
                continue
            if search and search.lower() not in app["name"].lower() \
                      and search.lower() not in app.get("description","").lower():
                continue
            card = AppCard(app, on_install=self._on_install_requested)
            self.flow.append(card)

    def on_category_selected(self, listbox, row):
        if row:
            self.current_category = row.category
            self._populate_apps(self.search_entry.get_text())

    def on_search(self, entry):
        self._populate_apps(entry.get_text())

    def _on_install_requested(self, app):
        toast = Adw.Toast.new(f"Installing {app['name']}…")
        self.toast_overlay.add_toast(toast)
        self.installer.install_async(app, callback=self._on_install_done)

    def _on_install_done(self, app, success, error_msg=""):
        def notify():
            if success:
                msg = f"{app['name']} installed!"
            else:
                msg = f"Failed: {error_msg[:60]}"
            toast = Adw.Toast.new(msg)
            toast.set_timeout(4)
            self.toast_overlay.add_toast(toast)
        GLib.idle_add(notify)
