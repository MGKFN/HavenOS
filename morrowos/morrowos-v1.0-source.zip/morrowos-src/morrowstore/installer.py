"""
MorrowStore — Backend installer
Supports APT, Flatpak, Snap.
Runs installs in a background thread to keep UI responsive.
"""
import subprocess
import threading
import shutil

class Installer:
    def install_async(self, app: dict, callback):
        """Non-blocking install — runs in thread, calls callback(app, success, error) on finish."""
        t = threading.Thread(
            target=self._install_worker,
            args=(app, callback),
            daemon=True
        )
        t.start()

    def _install_worker(self, app: dict, callback):
        method = app.get("method", "apt")
        pkg = app.get("package")

        try:
            if method == "apt":
                self._run(["pkexec", "apt-get", "install", "-y", pkg])
            elif method == "flatpak":
                self._run(["flatpak", "install", "-y", "--noninteractive",
                           app.get("remote", "flathub"), pkg])
            elif method == "snap":
                self._run(["pkexec", "snap", "install", pkg])
            else:
                raise ValueError(f"Unknown install method: {method}")
            callback(app, True)
        except subprocess.CalledProcessError as e:
            callback(app, False, e.stderr or str(e))
        except Exception as e:
            callback(app, False, str(e))

    def _run(self, cmd):
        result = subprocess.run(
            cmd,
            check=True,
            capture_output=True,
            text=True
        )
        return result

    def is_installed(self, app: dict) -> bool:
        method = app.get("method", "apt")
        pkg = app.get("package")
        if method == "apt":
            r = subprocess.run(
                ["dpkg", "-s", pkg],
                capture_output=True
            )
            return r.returncode == 0
        elif method == "flatpak":
            r = subprocess.run(
                ["flatpak", "info", pkg],
                capture_output=True
            )
            return r.returncode == 0
        elif method == "snap":
            r = subprocess.run(
                ["snap", "list", pkg],
                capture_output=True
            )
            return r.returncode == 0
        return False
