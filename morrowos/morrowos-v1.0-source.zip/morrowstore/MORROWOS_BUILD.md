# MorrowOS — Branding Paths, Skinning, & Build Pipeline

---

## 3. BRANDING & SKINNING — EXACT PATHS

### Plymouth (Boot Splash)

Plymouth shows while the kernel loads before the display manager starts.

```
/usr/share/plymouth/themes/morrow/          ← your theme directory
    morrow.plymouth                          ← theme descriptor
    morrow.script                            ← Plymouth script (animation logic)
    logo.png                                 ← your boot logo
    background.png                           ← boot background

/etc/plymouth/plymouthd.conf                ← set Theme=morrow here
/usr/share/plymouth/themes/default.plymouth ← symlink → morrow.plymouth
```

**morrow.plymouth:**
```ini
[Plymouth Theme]
Name=MorrowOS
Description=MorrowOS Boot Splash
ModuleName=script

[script]
ImageDir=/usr/share/plymouth/themes/morrow
ScriptFile=/usr/share/plymouth/themes/morrow/morrow.script
```

**plymouthd.conf:**
```ini
[Daemon]
Theme=morrow
ShowDelay=0
```

After placing files, run inside chroot:
```bash
update-alternatives --install /usr/share/plymouth/themes/default.plymouth \
    default.plymouth /usr/share/plymouth/themes/morrow/morrow.plymouth 100
update-initramfs -u
```

---

### SDDM (Login Screen)

```
/usr/share/sddm/themes/morrow/              ← your SDDM theme
    Main.qml                                 ← QML login screen layout
    theme.conf                               ← theme metadata
    background.jpg                           ← login wallpaper
    logo.svg                                 ← shown on login screen

/etc/sddm.conf.d/morrow-theme.conf          ← activate your theme
```

**morrow-theme.conf:**
```ini
[Theme]
Current=morrow
```

**theme.conf:**
```ini
[General]
background=background.jpg
type=image
```

SDDM uses QML — `Main.qml` gives you full control of layout, fonts, animations. Copy from `/usr/share/sddm/themes/breeze/` as a starting point.

---

### KDE Plasma Desktop Skin

**Global theme (Plasma Look and Feel):**
```
/usr/share/plasma/look-and-feel/os.morrow.desktop/
    metadata.json
    contents/
        defaults                             ← sets colorscheme, wallpaper, icons
        layouts/
            org.kde.plasma.desktop-layout.js ← panel/widget layout
        previews/
            fullscreenpreview.jpg
```

**Color scheme:**
```
/usr/share/color-schemes/MorrowDark.colors  ← KDE color scheme file
```

**Icon theme:**
```
/usr/share/icons/morrow/                    ← your icon theme
    index.theme
    16x16/apps/
    22x22/apps/
    32x32/apps/
    48x48/apps/
    scalable/apps/                           ← SVG icons here
```

**Wallpaper:**
```
/usr/share/wallpapers/MorrowOS/
    metadata.json
    contents/
        images/
            3840x2160.jpg
            1920x1080.jpg
            1280x720.jpg
```

**GTK theme (for GTK apps to match):**
```
/usr/share/themes/Morrow/
    gtk-3.0/gtk.css
    gtk-4.0/gtk.css
    index.theme
```

---

### /etc/skel/ — Forced Defaults for All Users

Everything here lands in every new user's home on account creation,
AND you copy it to /home/morrow/ for the live session.

```
/etc/skel/.config/
    plasmarc                                 ← LookAndFeelPackage=os.morrow.desktop
    kdeglobals                               ← ColorScheme=MorrowDark, font settings
    kwinrc                                   ← window decoration, effects
    kscreenlockerrc                          ← lockscreen wallpaper/theme
    plasma-org.kde.plasma.desktop-appletsrc  ← exact panel/taskbar layout (export from working setup)
    gtk-3.0/settings.ini                     ← gtk-theme-name=Morrow, icon-theme-name=morrow
/etc/skel/.local/share/
    wallpapers/                              ← optional, or point to /usr/share/wallpapers/MorrowOS
```

**plasmarc minimum content:**
```ini
[KDE]
LookAndFeelPackage=os.morrow.desktop

[Theme]
name=morrow
```

**kdeglobals minimum content:**
```ini
[General]
ColorScheme=MorrowDark

[Icons]
Theme=morrow

[KDE]
widgetStyle=Breeze
```

---

### App Menu / Application Names

```
/usr/share/applications/*.desktop            ← modify Name= fields here
/usr/share/applications/mimeinfo.cache       ← regenerate with update-desktop-database
```

To rename or hide default apps, edit or mask their `.desktop` files.
To add MorrowStore to the menu:
```
/usr/share/applications/morrowstore.desktop
```

---

## 4. BUILD PIPELINE — CHRONOLOGICAL

### Step 0: Directory Structure

```
morrowos-build/
├── chroot/                 ← debootstrap base (becomes squashfs)
├── iso-stage/              ← ISO layout
│   ├── casper/
│   │   ├── filesystem.squashfs
│   │   ├── filesystem.size
│   │   ├── vmlinuz
│   │   └── initrd
│   ├── isolinux/
│   │   ├── isolinux.cfg
│   │   └── *.c32 / *.bin
│   └── .disk/
│       └── info
├── branding/               ← your assets (logos, wallpapers, themes)
├── morrowstore/            ← App Manager source
└── build.sh                ← master build script
```

---

### Step 1: Bootstrap the Base System

```bash
debootstrap --arch=amd64 noble ./chroot http://archive.ubuntu.com/ubuntu
```

---

### Step 2: Mount Chroot and Install Packages

```bash
mount --bind /dev chroot/dev
mount --bind /dev/pts chroot/dev/pts
mount -t proc proc chroot/proc
mount -t sysfs sysfs chroot/sys

chroot ./chroot /bin/bash << 'CHROOT'
apt-get update
apt-get install -y --no-install-recommends \
    linux-image-generic \
    casper \
    lupin-casper \
    discover \
    laptop-detect \
    os-prober \
    network-manager \
    plymouth \
    plymouth-themes \
    sddm \
    plasma-desktop \
    kwin-x11 \           # ← MUST be explicit, not via recommends
    dbus-x11 \           # ← MUST be explicit
    python3-gi \
    gir1.2-gtk-4.0 \
    gir1.2-adw-1 \
    flatpak \
    xserver-xorg-video-vesa \
    xserver-xorg-video-fbdev \
    calamares \
    calamares-settings-ubuntu
apt-get clean
CHROOT
```

---

### Step 3: Install Branding Assets

```bash
# Plymouth theme
cp -r branding/plymouth/morrow chroot/usr/share/plymouth/themes/
chroot ./chroot update-alternatives --install \
    /usr/share/plymouth/themes/default.plymouth \
    default.plymouth \
    /usr/share/plymouth/themes/morrow/morrow.plymouth 100
chroot ./chroot update-initramfs -u

# SDDM theme
cp -r branding/sddm/morrow chroot/usr/share/sddm/themes/
cat > chroot/etc/sddm.conf.d/morrow-theme.conf << 'EOF'
[Theme]
Current=morrow
[Autologin]
User=morrow
Session=plasma
Relogin=false
EOF

# Plasma Look and Feel
cp -r branding/plasma/os.morrow.desktop \
    chroot/usr/share/plasma/look-and-feel/

# Icon theme
cp -r branding/icons/morrow chroot/usr/share/icons/
chroot ./chroot gtk-update-icon-cache /usr/share/icons/morrow

# Wallpapers
cp -r branding/wallpapers/MorrowOS chroot/usr/share/wallpapers/

# GTK theme
cp -r branding/gtk/Morrow chroot/usr/share/themes/
```

---

### Step 4: Install MorrowStore

```bash
mkdir -p chroot/usr/lib/morrowstore
cp morrowstore/*.py chroot/usr/lib/morrowstore/

# Launcher script
cat > chroot/usr/bin/morrowstore << 'EOF'
#!/bin/bash
exec python3 /usr/lib/morrowstore/main.py "$@"
EOF
chmod +x chroot/usr/bin/morrowstore

# Default catalog
mkdir -p chroot/usr/share/morrowstore
cp morrowstore/catalog.json chroot/usr/share/morrowstore/

# Desktop file
cp morrowstore/morrowstore.desktop chroot/usr/share/applications/
```

---

### Step 5: Configure /etc/skel/ and Live User

```bash
# Skel — for installed users
cp -r branding/skel/.config chroot/etc/skel/
cp -r branding/skel/.local  chroot/etc/skel/

# Create live user
chroot ./chroot useradd -m -s /bin/bash -u 1000 morrow
chroot ./chroot usermod -aG sudo,audio,video,netdev morrow
echo "morrow:morrow" | chroot ./chroot chpasswd

# Apply skel to live user home
cp -r chroot/etc/skel/. chroot/home/morrow/
chroot ./chroot chown -R 1000:1000 /home/morrow
```

---

### Step 6: Configure SDDM / Casper

```bash
# Fix 15autologin to write Session=plasma not Session=plasma.desktop
python3 fix_casper_autologin.py chroot/

# Set default display manager
echo "/usr/bin/sddm" > chroot/etc/X11/default-display-manager

# Rebuild initrd to bake plymouth + casper hooks
chroot ./chroot update-initramfs -u

# Copy kernel + initrd to iso-stage
cp chroot/boot/vmlinuz-* iso-stage/casper/vmlinuz
cp chroot/boot/initrd.img-* iso-stage/casper/initrd
```

---

### Step 7: Squash the Filesystem

```bash
umount chroot/sys chroot/proc chroot/dev/pts chroot/dev
mksquashfs chroot iso-stage/casper/filesystem.squashfs \
    -comp zstd -Xcompression-level 15 -noappend
du -sx --block-size=1 chroot | cut -f1 > iso-stage/casper/filesystem.size
```

---

### Step 8: Build the ISO

```bash
xorriso -as mkisofs \
    -iso-level 3 \
    -full-iso9660-filenames \
    -volid "MORROWOS" \
    -eltorito-boot isolinux/isolinux.bin \
    -eltorito-catalog isolinux/boot.cat \
    -no-emul-boot -boot-load-size 4 -boot-info-table \
    -isohybrid-mbr /usr/lib/ISOLINUX/isohdpfx.bin \
    -output morrowos-v1.0.0.iso \
    iso-stage/
```

---

### Step 9: Test

```bash
# VirtualBox — use VMSVGA display adapter, not VBoxVGA
# QEMU
qemu-system-x86_64 -m 3072 -smp 2 -cdrom morrowos-v1.0.0.iso -boot d -vga std
```

---

## CLARIFYING QUESTIONS

To refine this further, answer these:

1. **App Manager UI style** — do you want a dark theme, a specific accent color, or a particular aesthetic (minimal/modern/bold)?
2. **MorrowStore catalog** — local JSON only, or do you want a hosted remote catalog the app fetches from a URL (so you can push new apps without an OS update)?
3. **Install methods priority** — APT only for now, or do you want Flatpak/Snap support from day one?
4. **Plymouth animation** — static logo fade, animated spinner, or a custom animated sequence?
5. **Calamares installer** — do you want MorrowOS to be installable to disk, or live-only for now?
6. **Branding assets** — do you have logos/wallpapers already, or do you need those designed too?
